# Player card data, transcribed from the printed cards (the cards are the source of truth).
# Values: number + band (H above average, A average, L below average).
# Offence: dribble, pass, screen | layup, dunk, post, floater, mid, long2, three, free throw
# Defence: agility, intercept, challenge, steal, foul(steal) | layup, dunk, post, floater, mid, long2, three, foul(contest)
# qs: Quick Step from the speed colour (green 2, yellow 1, red 0)
CARDS = [
 # key, piece no, role, tier, tagline, qs, offence, defence
 ('apgA',1,'Attacking Point Guard','A','Explosive athlete. Elite finisher. Average shooter.',2,
  '19H 15A 14A | 19H 18H 11L 15H 10A 9A 9A 14A', '8H 8H 8H 4H 7A | 7A 7A 4A 5A 5A 4A 4A 9A'),
 ('apgB',1,'Attacking Point Guard','B','Quick athlete. Strong finisher. Unreliable shooter.',2,
  '17H 14A 12L | 19H 17A 10L 14H 9A 8A 8A 13L', '7A 7A 7A 3A 8A | 6L 5L 3L 4A 4A 3L 3L 10L'),
 ('apgC',1,'Attacking Point Guard','C','Decent attacker, limited shooter. Foul prone.',1,
  '16A 13L 11L | 18A 16A 9L 13H 8L 7L 7L 12L', '6A 7A 6A 3A 9L | 5L 4L 2L 3L 3L 2L 2L 11L'),
 ('cgA',1,'Combo Guard','A','Well-rounded. Above-average in most skills.',2,
  '17H 18H 15A | 18A 17A 11L 12A 10A 10H 9A 16A', '8H 8H 8H 3A 6H | 8A 8A 4A 5A 6A 5A 5A 10L'),
 ('cgB',1,'Combo Guard','B','Versatile skills. Above-average playmaking.',1,
  '15A 17H 13L | 18A 16A 10L 11A 9A 9A 9A 15A', '7A 7A 7A 3A 7A | 7A 6L 3L 4A 5A 4A 4A 11L'),
 ('cgC',1,'Combo Guard','C','Serviceable playmaker. Liability on defence.',1,
  '15A 16A 11L | 17L 15L 9L 10A 8L 8A 8A 15A', '5L 6A 5L 2A 8A | 5L 4L 2L 3L 3L 3L 3L 12L'),
 ('dpgA',1,'Defensive Point Guard','A','Elite defender. Great athlete. Average offence.',2,
  '16A 15A 16A | 18A 16A 10L 9L 8L 7L 8A 15A', '10H 9H 10H 5H 4H | 9A 10A 5A 5A 7H 6A 6H 7H'),
 ('dpgB',1,'Defensive Point Guard','B','Strong, athletic defender. Below-average offence.',1,
  '16A 14A 14A | 17L 15L 9L 8L 7L 7L 7L 14A', '9H 8H 9H 5H 5H | 8A 8A 4A 4A 6A 5A 5A 8A'),
 ('dpgC',1,'Defensive Point Guard','C','Undersized but smart defender. Poor offensive skill.',2,
  '15A 13L 12L | 17L 15L 8L 8L 7L 7L 7L 13L', '8H 7A 8H 4H 6H | 6L 6L 3L 3L 5A 4A 4A 9A'),
 ('spgA',1,'Scoring Point Guard','A','Elite scorer and ball-handler. Average defence.',2,
  '19H 16A 14A | 19H 17A 12A 15H 11H 11H 10H 18H', '7A 7A 7A 3A 7A | 7A 7A 4A 4A 4A 3L 3L 9A'),
 ('spgB',1,'Scoring Point Guard','B','Confident scorer and ball-handler. Poor defender.',1,
  '18H 15A 12L | 18A 16A 11L 14H 10A 10H 9A 17H', '6A 6A 6A 3A 8A | 6L 5L 3L 3L 3L 3L 3L 10L'),
 ('spgC',1,'Scoring Point Guard','C','Solid scorer. Good handles. Weak defence. Foul prone.',1,
  '17H 14A 11L | 18A 15L 10L 13H 9A 9A 8A 16A', '5L 6A 5L 2A 9L | 5L 4L 2L 3L 3L 3L 3L 11L'),
 ('ppgA',1,'Pass-First Point Guard','A','Elite playmaker. Strong handles. Average scoring.',2,
  '19H 20H 15A | 18A 16A 10L 11A 10A 8A 9A 15A', '8H 7A 8H 3A 6H | 8A 8A 4A 4A 5A 4A 4A 9A'),
 ('ppgB',1,'Pass-First Point Guard','B','Good playmaker. Solid handles. Limited scoring.',1,
  '18H 19H 13L | 17L 15L 9L 10A 9A 7L 8A 14A', '7A 6A 7A 3A 7A | 7A 6L 3L 3L 4A 3L 3L 10L'),
 ('ppgC',1,'Pass-First Point Guard','C','Decent playmaker. Good handles. Poor scorer.',1,
  '17H 18H 11L | 17L 15L 9L 9L 8L 7L 7L 13L', '6A 5L 6A 3A 8A | 6L 4L 2L 3L 3L 3L 3L 11L'),
 ('twA',2,'Two-Way Shooting Guard','A','Strong defender and scorer. Well-rounded skills.',1,
  '15A 15A 16A | 18A 17A 12A 11A 10A 10H 9A 16A', '9H 9H 9H 5H 5H | 9A 10A 5A 5A 7H 6A 6H 7H'),
 ('twB',2,'Two-Way Shooting Guard','B','Solid defender and scorer. Balanced skills.',1,
  '14A 15A 14A | 18A 16A 11L 10A 10A 9A 9A 15A', '8H 8H 8H 4H 6H | 8A 8A 4A 4A 6A 5A 5A 8A'),
 ('twC',2,'Two-Way Shooting Guard','C','Jack-of-all-trades. No standout skills.',1,
  '14A 13L 12L | 17L 15L 10L 9L 9A 8A 8A 15A', '7A 7A 7A 4H 7A | 6L 6L 3L 3L 5A 4A 4A 9A'),
 ('tndA',2,'Three-and-D Shooting Guard','A','Elite defender. Excellent shooter. Limited playmaking.',1,
  '14A 13L 15A | 18A 16A 11L 9L 11H 11H 10H 17H', '9H 8H 9H 5H 5H | 9A 10A 5A 5A 8H 7H 7H 7H'),
 ('tndB',2,'Three-and-D Shooting Guard','B','Good defender and shooter. Limited playmaking.',1,
  '13L 12L 13L | 17L 15L 10L 8L 10A 10H 9A 17H', '8H 8H 8H 4H 6H | 8A 8A 4A 4A 7H 6A 6H 8A'),
 ('tndC',2,'Three-and-D Shooting Guard','C','Decent at shooting and defending shooters.',1,
  '12L 11L 11L | 17L 15L 9L 8L 9A 9A 8A 16A', '7A 7A 7A 3A 7A | 6L 6L 3L 3L 6A 5A 5A 9A'),
 ('pmsA',2,'Playmaker Shooting Guard','A','Elite playmaker. Decent scorer. Average defender.',1,
  '18H 18H 15A | 18A 16A 12A 13H 10A 9A 9A 16A', '7A 7A 7A 3A 6H | 8A 8A 4A 5A 5A 4A 4A 10L'),
 ('pmsB',2,'Playmaker Shooting Guard','B','Strong playmaker. Average scorer.',1,
  '17H 17H 13L | 18A 15L 11L 11A 9A 8A 8A 15A', '6A 6A 6A 3A 7A | 7A 6L 3L 4A 4A 4A 3L 11L'),
 ('pmsC',2,'Playmaker Shooting Guard','C','Solid playmaker. Poor defender. Foul prone.',1,
  '16A 16A 11L | 17L 15L 10L 11A 8L 7L 7L 14A', '5L 6A 5L 2A 8A | 5L 4L 2L 3L 3L 3L 3L 12L'),
 ('shsA',2,'Sharpshooter Shooting Guard','A','Elite spot-up shooter. Average defender.',1,
  '15A 14A 14A | 18A 16A 11L 12A 12H 11H 11H 18H', '7A 6A 7A 2A 7A | 8A 8A 4A 4A 4A 4A 3L 9A'),
 ('shsB',2,'Sharpshooter Shooting Guard','B','Spot-up shooter. Poor playmaking. Weak defence.',1,
  '14A 13L 12L | 17L 15L 10L 11A 11H 10H 10H 17H', '6A 6A 6A 2A 8A | 7A 6L 3L 3L 3L 3L 3L 10L'),
 ('shsC',2,'Sharpshooter Shooting Guard','C','Decent spot-up shooter. Liability on defence.',1,
  '13L 12L 11L | 17L 15L 9L 10A 10A 9A 9A 16A', '5L 5L 5L 1L 9L | 5L 4L 2L 3L 3L 3L 3L 11L'),
 ('bgsA',2,'Bucket Getter Shooting Guard','A','Elite scorer. Average defender. Foul prone.',2,
  '18H 13L 14A | 19H 18H 13A 15H 11H 11H 10H 18H', '7A 7A 6A 2A 8A | 7A 7A 4A 4A 4A 4A 3L 11L'),
 ('bgsB',2,'Bucket Getter Shooting Guard','B','Strong scorer. Weak defender. Foul prone.',1,
  '17H 12L 12L | 19H 17A 12A 14H 10A 10H 9A 17H', '6A 7A 5L 2A 9L | 6L 5L 3L 3L 3L 3L 3L 12L'),
 ('bgsC',2,'Bucket Getter Shooting Guard','C','Good attacker. Poor defender. Foul prone.',1,
  '17H 11L 11L | 18A 16A 11L 13H 9A 9A 8A 16A', '5L 6A 4L 2A 10L | 5L 4L 2L 3L 3L 3L 3L 12L'),
 ('dpfA',4,'Defensive Power Forward','A','Elite defender. Athletic finisher. Poor shooter.',1,
  '14A 12L 17H | 18A 18H 15H 8L 8L 7L 7L 15A', '8H 9H 9H 4H 6H | 11H 13H 7H 5A 8H 8H 7H 5H'),
 ('dpfB',4,'Defensive Power Forward','B','Good defender. Solid finisher. Poor shooter.',0,
  '12L 11L 16A | 18A 17A 14A 8L 7L 7L 6L 14A', '7A 8H 8H 4H 7A | 10H 11H 6H 4A 7H 7H 6H 6H'),
 ('dpfC',4,'Defensive Power Forward','C','Serviceable defender. Liability on offence.',0,
  '11L 11L 15A | 17L 16A 13A 8L 7L 7L 6L 12L', '6A 7A 7A 3A 8A | 8A 10A 5A 3L 6A 6A 5A 7H'),
 ('arpfA',4,'All-Rounder Power Forward','A','Versatile scorer. Solid defender.',1,
  '15A 15A 18H | 19H 18H 16H 9L 10A 9A 8A 15A', '7A 7A 8H 3A 7A | 10H 12H 6H 5A 6A 6A 5A 7H'),
 ('arpfB',4,'All-Rounder Power Forward','B','Balanced scorer. Average defender.',1,
  '13L 14A 17H | 18A 17A 15H 8L 9A 8A 7L 14A', '6A 6A 7A 3A 8A | 9A 10A 5A 4A 5A 5A 4A 8A'),
 ('arpfC',4,'All-Rounder Power Forward','C','Decent screener. No other standout skills.',0,
  '12L 13L 16A | 17L 16A 14A 8L 8L 7L 7L 12L', '5L 5L 6A 2A 9L | 7A 9A 4A 3L 4A 4A 3L 9A'),
 ('pnpA',4,'Pick-and-Pop Power Forward','A','Elite screener. Good shooter. Foul-prone defender.',1,
  '16A 14A 19H | 18A 18H 15H 9L 10A 10H 9A 16A', '6A 7A 7A 2A 8A | 9A 11H 5A 5A 5A 5A 4A 9A'),
 ('pnpB',4,'Pick-and-Pop Power Forward','B','Strong screener. Average shooter. Poor defender.',0,
  '15A 13L 18H | 18A 17A 14A 8L 9A 9A 8A 15A', '5L 6A 6A 2A 9L | 8A 9A 4A 4A 4A 4A 3L 10L'),
 ('pnpC',4,'Pick-and-Pop Power Forward','C','Good screener. Average shooter. Poor defender.',0,
  '14A 12L 17H | 17L 16A 13A 8L 8L 8A 7L 14A', '4L 5L 5L 2A 10L | 6L 8A 3L 3L 3L 3L 3L 11L'),
 # stpfA defence: card printed colours but no numbers; values are tier B + 1 (provisional, awaiting confirmation)
 ('stpfA',4,'Stretch Power Forward','A','Strong shooter. Average, foul-prone defender.',1,
  '14A 14A 16A | 18A 17A 14A 10A 11H 11H 9A 18H', '6A 7A 7A 3A 8A | 9A 11H 5A 5A 5A 5A 4A 9A'),
 ('stpfB',4,'Stretch Power Forward','B','Good shooter. Below-average defender.',0,
  '12L 13L 15A | 17L 16A 13A 9L 10A 10H 8A 16A', '5L 6A 6A 2A 9L | 8A 9A 4A 4A 4A 4A 3L 10L'),
 ('stpfC',4,'Stretch Power Forward','C','Average shooter. Poor defender.',0,
  '11L 12L 14A | 17L 15L 12A 8L 9A 9A 7L 14A', '4L 5L 5L 2A 10L | 6L 8A 3L 3L 3L 3L 3L 11L'),
 ('pspfA',4,'Post Scorer Power Forward','A','Dominant inside scorer. Slow, imposing defender.',0,
  '14A 13L 18H | 19H 19H 17H 9L 9A 7L 7L 15A', '6A 6A 6A 2A 9L | 10H 12H 6H 5A 6A 6A 5A 8A'),
 ('pspfB',4,'Post Scorer Power Forward','B','Strong inside scorer and screener. Slow defender.',0,
  '12L 13L 17H | 19H 18H 16H 8L 8L 7L 6L 13L', '5L 6A 5L 2A 10L | 9A 10A 5A 4A 5A 5A 4A 9A'),
 ('pspfC',4,'Post Scorer Power Forward','C','Decent inside scorer. Poor shooter and defender.',0,
  '11L 13L 16A | 18A 17A 15H 8L 8L 7L 6L 12L', '4L 5L 4L 1L 11L | 7A 9A 4A 3L 4A 4A 3L 10L'),
 ('rpcA',5,'Rim Protector Centre','A','Elite defender. Strong post moves. Poor shooter.',0,
  '12L 12L 18H | 18A 18H 16H 8L 8L 7L 6L 12L', '7A 9H 8H 3A 7A | 12H 14H 8H 7H 8H 8H 6H 4H'),
 ('rpcB',5,'Rim Protector Centre','B','Strong defender. Good post moves. Poor shooter.',0,
  '11L 12L 17H | 18A 17A 15H 8L 7L 7L 6L 12L', '6A 8H 7A 2A 8A | 11H 12H 7H 6A 7H 7H 5A 5H'),
 ('rpcC',5,'Rim Protector Centre','C','Decent defender. Limited offence. Poor shooter.',0,
  '11L 11L 16A | 17L 16A 14A 8L 7L 7L 5L 10L', '5L 7A 6A 2A 9L | 9A 11H 6H 5A 6A 6A 4A 6H'),
 ('stcA',5,'Stretch Centre','A','Good shooter. Versatile skill set. Average defender.',1,
  '15A 14A 16A | 18A 17A 15H 9L 11H 10H 9A 15A', '6A 6A 7A 3A 8A | 10H 12H 6H 6A 6A 6A 5A 7H'),
 ('stcB',5,'Stretch Centre','B','Decent shooter. Average defender with poor footwork.',0,
  '14A 13L 15A | 17L 16A 14A 8L 10A 9A 8A 14A', '5L 6A 6A 3A 9L | 9A 10A 5A 5A 5A 5A 4A 8A'),
 ('stcC',5,'Stretch Centre','C','Average shooter. Poor defender. Limited athleticism.',0,
  '13L 12L 14A | 17L 15L 13A 8L 9A 8A 7L 14A', '4L 5L 5L 2A 10L | 7A 9A 4A 4A 3L 3L 3L 9A'),
 ('pmcA',5,'Playmaking Centre','A','Great passer and screener with a versatile skill set.',0,
  '16A 17H 17H | 18A 18H 16H 11A 10A 8A 7L 17H', '6A 7A 7A 4H 7A | 10H 12H 6H 5A 5A 5A 4A 8A'),
 ('pmcB',5,'Playmaking Centre','B','Good passer and screener. Struggles defending guards.',0,
  '14A 16A 16A | 18A 17A 15H 10A 9A 7L 7L 15A', '5L 6A 6A 2A 8A | 9A 10A 5A 5A 4A 4A 3L 9A'),
 ('pmcC',5,'Playmaking Centre','C','Good passer. Poor defender.',0,
  '14A 15A 15A | 17L 16A 14A 9L 8L 7L 6L 13L', '4L 5L 5L 2A 9L | 7A 9A 4A 4A 3L 3L 3L 10L'),
 ('pscA',5,'Post Scorer Centre','A','Elite inside scorer. Shot blocker. Poor perimeter skills.',0,
  '14A 13L 19H | 19H 19H 18H 9L 8L 7L 6L 14A', '5L 6A 5L 2A 9L | 11H 13H 7H 5A 6A 6A 4A 6H'),
 ('pscB',5,'Post Scorer Centre','B','Strong inside scorer and screener. Poor perimeter skills.',0,
  '13L 12L 18H | 19H 18H 17H 8L 8L 7L 6L 13L', '4L 6A 4L 2A 10L | 10H 11H 6H 4A 5A 5A 3L 7H'),
 ('pscC',5,'Post Scorer Centre','C','Inside scorer. Poor defender. Lacks perimeter skills.',0,
  '12L 11L 17H | 18A 17A 16H 8L 7L 7L 6L 11L', '3L 5L 4L 1L 11L | 8A 10A 5A 4A 4A 4A 3L 8A'),
 ('rrcA',5,'Rim Runner Centre','A','Elite, athletic finisher. Strong defender. Poor shooter.',1,
  '12L 12L 18H | 19H 19H 16H 9L 8L 7L 6L 12L', '7A 8H 6A 4H 8A | 11H 13H 7H 6A 7H 7H 5A 5H'),
 ('rrcB',5,'Rim Runner Centre','B','Strong, fast finisher. Good athlete. Poor shooter.',1,
  '11L 11L 17H | 19H 19H 15H 8L 7L 7L 6L 11L', '6A 7A 5L 3A 9L | 10H 11H 6H 5A 6A 6A 4A 6H'),
 ('rrcC',5,'Rim Runner Centre','C','Decent finisher. Average defender. Limited skill set.',1,
  '11L 11L 16A | 18A 17A 14A 8L 7L 7L 5L 10L', '5L 6A 4L 2A 10L | 8A 10A 5A 4A 5A 5A 3L 7H'),
 ('twsfA',3,'Two-Way Small Forward','A','Great defender and scorer. Versatile player.',1,
  '16A 15A 17H | 18A 17A 14A 11A 10A 9A 9A 16A', '9H 9H 9H 4H 6H | 10H 11H 6H 5A 7H 7H 6H 8A'),
 ('twsfB',3,'Two-Way Small Forward','B','Good defender. Well-rounded skills. Solid athlete.',1,
  '15A 14A 15A | 18A 16A 13A 10A 9A 8A 8A 15A', '8H 8H 8H 3A 7A | 9A 9A 5A 4A 6A 6A 5A 9A'),
 ('stsfA',3,'Stretch Small Forward','A','Excellent shooter. Serviceable all-round skills.',1,
  '15A 14A 15A | 18A 16A 13A 11A 10A 11H 10H 17H', '7A 6A 7A 3A 7A | 9A 10A 5A 5A 6A 5A 5A 9A'),
 ('stsfB',3,'Stretch Small Forward','B','Good shooter. Decent size. Average defender. Foul prone.',1,
  '15A 13L 13L | 17L 15L 12A 10A 9A 10H 9A 15A', '6A 6A 6A 2A 8A | 8A 8A 4A 4A 5A 5A 4A 10L'),
 ('dfsfA',3,'Defensive Small Forward','A','Elite defender. Great athlete. Limited on offence.',1,
  '14A 13L 17H | 18A 17A 13A 9L 8L 7L 7L 14A', '9H 9H 10H 5H 5H | 10H 12H 7H 5A 8H 8H 7H 6H'),
 ('dfsfB',3,'Defensive Small Forward','B','Strong defender. Good athlete. Poor offensive game.',1,
  '13L 12L 15A | 18A 16A 12A 8L 8L 7L 7L 14A', '8H 8H 9H 4H 6H | 9A 10A 6H 4A 7H 7H 6H 7H'),
 ('scsfA',3,'Scoring Small Forward','A','Elite, athletic scorer. Solid defender.',1,
  '18H 15A 15A | 19H 18H 15H 12A 11H 11H 9A 17H', '7A 7A 7A 3A 7A | 8A 10A 5A 5A 5A 5A 4A 9A'),
 ('scsfB',3,'Scoring Small Forward','B','Strong scorer. Good athlete. Average defender.',1,
  '17H 14A 13L | 19H 17A 14A 11A 10A 10H 8A 16A', '6A 7A 6A 2A 8A | 7A 8A 4A 4A 4A 4A 3L 10L'),
 ('pfsfA',3,'Point Forward Small Forward','A','Elite playmaker. Great athleticism. Strong scorer.',1,
  '18H 18H 17H | 18A 17A 15H 11A 10A 10H 9A 16A', '7A 7A 8H 3A 6H | 9A 10A 5A 5A 6A 6A 5A 10L'),
 ('pfsfB',3,'Point Forward Small Forward','B','Strong playmaker. Good size. Versatile scorer.',1,
  '16A 17H 15A | 18A 16A 14A 10A 9A 9A 8A 15A', '6A 7A 7A 2A 7A | 8A 8A 4A 4A 5A 5A 4A 11L'),
 # Small Forward tier C: never printed. Derived by cards/derive_sf_c.py (tier B minus the median B-to-C drop
 # across the other 20 archetypes, clamped to the printed range; tested at 85% exact on held-out archetypes).
 # Quick Step from speed: A-to-C speed drops 1 in total on every Centre archetype.
 ('twsfC',3,'Two-Way Small Forward','C','Decent defender and scorer. No standout skills.',1,
  '14A 13L 14A | 17L 15L 12A 10A 8L 7L 7L 14A', '7A 7A 7A 2A 8A | 7A 8A 4A 3L 5A 5A 4A 10L'),
 ('stsfC',3,'Stretch Small Forward','C','Decent shooter. Poor defender. Foul prone.',0,
  '14A 12L 12L | 17L 15L 11L 10A 8L 9A 8A 14A', '5L 5L 5L 1L 9L | 6L 7A 3L 3L 4A 4A 3L 11L'),
 ('dfsfC',3,'Defensive Small Forward','C','Solid defender. Poor offensive game.',1,
  '12L 11L 14A | 17L 15L 11L 8L 7L 7L 6L 13L', '7A 7A 8H 3A 7A | 7A 9A 5A 3L 6A 6A 5A 8A'),
 ('scsfC',3,'Scoring Small Forward','C','Decent scorer. Poor defender. Foul prone.',1,
  '16A 13L 12L | 18A 16A 13A 11A 9A 9A 7L 15A', '5L 6A 5L 1L 9L | 5L 7A 3L 3L 3L 3L 2L 11L'),
 ('pfsfC',3,'Point Forward Small Forward','C','Decent playmaker. Average scorer. Weak defender.',1,
  '15A 16A 14A | 17L 15L 13A 10A 8L 8A 7L 14A', '5L 6A 6A 1L 8A | 6L 7A 3L 3L 4A 4A 3L 12L'),
]
# D-184 (Shaun, 14 Nov 2026): two new types, the app only for now. The table plays the 25 types above.
APP_CARDS = [
 # key, piece no, role, tier, tagline, qs, offence, defence
 ('slsfA',3,'Slashing Wing','A','Explosive slasher. Lives at the rim. Poor shooter.',2,
  '17H 14A 13L | 19H 19H 12A 11A 9A 8A 7L 16A', '9H 8H 8H 4H 7A | 8A 10A 5A 5A 5A 5A 4A 9A'),
 ('slsfB',3,'Slashing Wing','B','Strong driver. Finishes through contact. Unreliable shooter.',2,
  '16A 13L 12L | 18A 19H 11L 10A 8L 7L 6L 15A', '8H 7A 7A 3A 8A | 7A 8A 4A 4A 4A 4A 3L 10L'),
 ('slsfC',3,'Slashing Wing','C','Willing driver. Limited range.',1,
  '15A 12L 11L | 17L 18H 10L 9L 7L 7L 6L 14A', '7A 6A 6A 3A 9L | 5L 7A 3L 3L 3L 3L 2L 11L'),
 ('swcA',5,'Switch Centre','A','Elite switcher. Guards one to five. Rim runner.',2,
  '14A 13L 16A | 19H 19H 13A 9L 9A 7L 6L 14A', '9H 7A 8H 3A 6H | 11H 13H 7H 5A 8H 8H 7H 6H'),
 ('swcB',5,'Switch Centre','B','Mobile big. Holds up on switches. Limited range.',1,
  '13L 12L 15A | 18A 19H 12A 8L 8L 7L 5L 13L', '8H 6A 7A 3A 7A | 10H 11H 6H 4A 7H 7H 6H 7H'),
 ('swcC',5,'Switch Centre','C','Serviceable switcher. Finishes inside.',1,
  '12L 11L 14A | 17L 18H 11L 8L 7L 6L 5L 13L', '7A 5L 6A 2A 8A | 8A 10A 5A 3L 6A 6A 5A 8A'),
]
APP_ONLY = {row[0] for row in APP_CARDS}
TABLE_CARDS = list(CARDS)
CARDS = CARDS + APP_CARDS

OFF = ['dribble', 'pass', 'screen', 'shot_layup', 'shot_dunk', 'shot_post', 'shot_floater', 'shot_mid', 'shot_long', 'shot_three', 'free_throw']
DEF = ['agility', 'intercept', 'challenge', 'steal', 'foul_steal', 'con_layup', 'con_dunk', 'con_post', 'con_floater', 'con_mid', 'con_long', 'con_three', 'foul_contest']
# D-269, D-270 (Shaun, 20 Nov 2026): Block and Foul (Block), from docs/reference/step29/BLOCK_RATINGS.csv (his ratings
# PDF's 75 cards, read in card order; PG-5 Slasher A corrected to 6 and 9). Each app type -> the PDF type it is, then
# (block, foul_block) for tiers A, B, C. The two app-only types (D-184) have no PDF type: Shaun rated them (D-277).
BLOCK_TYPE = {
 'apg': 'PG-5', 'cg': 'PG-4', 'dpg': 'PG-3', 'ppg': 'PG-1', 'spg': 'PG-2', 'bgs': 'SG-5', 'pms': 'SG-4', 'shs': 'SG-1', 'tnd': 'SG-3', 'tw': 'SG-2', 'dfsf': 'SF-5', 'pfsf': 'SF-4', 'scsf': 'SF-1', 'stsf': 'SF-3', 'twsf': 'SF-2', 'arpf': 'PF-4', 'dpf': 'PF-3', 'pnp': 'PF-5', 'pspf': 'PF-1', 'stpf': 'PF-2', 'pmc': 'C-4', 'psc': 'C-1', 'rpc': 'C-2', 'rrc': 'C-5', 'stc': 'C-3'}
BLOCK_RATINGS = {
 'PG-1': {'A': (5, 9), 'B': (4, 10), 'C': (4, 11)},
 'PG-2': {'A': (5, 9), 'B': (4, 10), 'C': (4, 11)},
 'PG-3': {'A': (7, 7), 'B': (6, 8), 'C': (5, 9)},
 'PG-4': {'A': (6, 10), 'B': (5, 11), 'C': (4, 12)},
 'PG-5': {'A': (6, 9), 'B': (5, 10), 'C': (4, 11)},
 'SG-1': {'A': (6, 9), 'B': (5, 10), 'C': (4, 11)},
 'SG-2': {'A': (8, 7), 'B': (7, 8), 'C': (6, 9)},
 'SG-3': {'A': (7, 7), 'B': (6, 8), 'C': (5, 9)},
 'SG-4': {'A': (6, 10), 'B': (5, 11), 'C': (4, 12)},
 'SG-5': {'A': (6, 11), 'B': (5, 12), 'C': (4, 12)},
 'SF-1': {'A': (7, 9), 'B': (6, 10), 'C': (5, 11)},
 'SF-2': {'A': (9, 8), 'B': (8, 9), 'C': (7, 10)},
 'SF-3': {'A': (7, 9), 'B': (6, 10), 'C': (5, 11)},
 'SF-4': {'A': (8, 10), 'B': (7, 11), 'C': (6, 12)},
 'SF-5': {'A': (10, 6), 'B': (9, 7), 'C': (8, 8)},
 'PF-1': {'A': (9, 8), 'B': (8, 9), 'C': (7, 10)},
 'PF-2': {'A': (7, 9), 'B': (6, 10), 'C': (5, 11)},
 'PF-3': {'A': (10, 5), 'B': (9, 6), 'C': (8, 7)},
 'PF-4': {'A': (8, 7), 'B': (7, 8), 'C': (6, 9)},
 'PF-5': {'A': (7, 9), 'B': (6, 10), 'C': (5, 11)},
 'C-1': {'A': (9, 6), 'B': (8, 7), 'C': (7, 8)},
 'C-2': {'A': (10, 4), 'B': (9, 5), 'C': (8, 6)},
 'C-3': {'A': (7, 7), 'B': (6, 8), 'C': (5, 9)},
 'C-4': {'A': (8, 8), 'B': (7, 9), 'C': (6, 10)},
 'C-5': {'A': (9, 5), 'B': (8, 6), 'C': (7, 7)},
}
# D-277 (Shaun, 20 Nov 2026): the two app-only types (D-184). The Switch Centre plays the Defensive PF's values (PF-3:
# "It's a defensive job"); the Slashing Wing has his own: the Two-Way SF's block (his athleticism) with the Bucket
# Getter's foul control (his indiscipline): "Higher chance of foul while also higher chance of a successful block".
BLOCK_RATINGS['APP-SW'] = {'A': (9, 11), 'B': (8, 12), 'C': (7, 12)}
BLOCK_RATINGS['APP-SC'] = dict(BLOCK_RATINGS['PF-3'])
BLOCK_TYPE.update({'slsf': 'APP-SW', 'swc': 'APP-SC'})
BLOCK_STAND_IN = {}
def block_of(key):
    t = key[:-1]
    return BLOCK_RATINGS[BLOCK_TYPE.get(t) or BLOCK_STAND_IN[t]][key[-1]]
def parse(s): return [(int(t[:-1]), t[-1]) for t in s.replace('|', ' ').split()]

# Ceiling: 19 on every rating except Pass (20 allowed: a pass only rolls when an intercept contests it, so it is never a sure thing).
# RANGE TABLE (locked 2 Nov 2026; jump shots and the open layup rescaled by D-184, 14 Nov 2026; every contest back on its first range by D-189 and D-194;
# the three jump-shot ratings corrected by D-186, same ranges). Each entry: (lowest average, lowest above average); below the first is below average.
# Every card colour is generated from this table. Layup ratings: 17->16 for the weakest finishers so finishing matters at the rim; top stays 19 (95%), no one is a sure thing.
RANGES = {'dribble': (14, 17), 'pass': (14, 17), 'screen': (14, 17), 'shot_layup': (18, 19), 'shot_dunk': (16, 18), 'shot_post': (12, 15), 'shot_floater': (10, 13), 'shot_mid': (9, 11), 'shot_long': (8, 10), 'shot_three': (8, 10), 'free_throw': (14, 17), 'agility': (6, 8), 'intercept': (6, 8), 'challenge': (6, 8), 'steal': (2, 4), 'con_layup': (7, 10), 'con_dunk': (7, 11), 'con_post': (4, 6), 'con_floater': (4, 7), 'con_mid': (4, 7), 'con_long': (4, 7), 'con_three': (4, 6), 'block': (6, 8)}
FOUL_RANGES = {'foul_steal': (6, 8), 'foul_contest': (7, 9), 'foul_block': (7, 9)}  # lower is better: (highest above average, highest average)
def band(name, v):
    if name in FOUL_RANGES:
        h, a = FOUL_RANGES[name]; return 'H' if v <= h else ('A' if v <= a else 'L')
    a, h = RANGES[name]
    return 'H' if v >= h else ('A' if v >= a else 'L')

# Colours changed from the printed card to match the range chart (printed colour first), kept for the end-of-set cutoff review.
# D-184: entries for ratings whose range changed are removed (they no longer apply).
# D-189 (step 18n): the inside contests are back at their values before D-184, with their ranges and the three floater
# contest entries D-184 removed. D-194 (step 18o): the mid-range, long two and three contests are back at their values
# before D-184 too (D-192's numbers are gone), with their ranges and their entries here as they were.
CHART_FIXES = [
 ('apgB','shot_dunk',17,'H','A'), ('apgB','con_layup',6,'A','L'),
 ('spgA','con_mid',4,'L','A'), ('cgA','con_long',5,'H','A'), ('twB','con_mid',6,'A','H'), ('tndB','con_long',6,'A','H'),
 ('tndC','con_mid',6,'A','H'), ('dpfC','con_mid',6,'A','H'), ('dpfC','con_long',6,'A','H'), ('arpfA','con_mid',6,'A','H'),
 ('arpfA','con_long',6,'A','H'), ('pspfA','con_mid',6,'A','H'), ('pspfA','con_long',6,'A','H'),
 ('rpcB','con_floater',6,'A','H'), ('rpcC','con_mid',6,'A','H'), ('rpcC','con_long',6,'A','H'), ('stcA','con_floater',6,'A','H'),
 ('stcA','con_mid',6,'A','H'), ('stcA','con_long',6,'A','H'), ('pscA','con_mid',6,'A','H'), ('pscA','con_long',6,'A','H'),
 ('rrcA','con_floater',6,'A','H'), ('rrcB','con_mid',6,'A','H'), ('rrcB','con_long',6,'A','H'),
]
# Provisional numbers (card printed colours only): stpfA defence = tier B + 1.
CHART_FIXES += [('twsfB','con_mid',6,'A','H'), ('twsfB','con_long',6,'A','H'), ('stsfA','con_mid',6,'A','H'), ('pfsfA','con_mid',6,'A','H'), ('pfsfA','con_long',6,'A','H')]
